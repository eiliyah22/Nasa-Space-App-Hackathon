/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        ocean: { 50: '#f0f9ff', 100: '#e0f2fe', 200: '#bae6fd', 400: '#38bdf8', 500: '#0ea5e9', 600: '#0284c7', 700: '#0369a1', 800: '#075985', 900: '#0c4a6e', 950: '#082f49' },
        coral: { 400: '#fb7185', 500: '#f43f5e', 600: '#e11d48' },
        lagoon: { 400: '#2dd4bf', 500: '#14b8a6', 600: '#0d9488' },
        sand: { 100: '#fef3c7', 200: '#fde68a', 700: '#b45309' }
      },
      fontFamily: {
        sans: ['Inter', 'system-ui', 'sans-serif']
      }
    },
  },
  plugins: [],
}